package com.rally;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.rallydev.rest.RallyRestApi;
import com.rallydev.rest.request.GetRequest;
import com.rallydev.rest.request.QueryRequest;
import com.rallydev.rest.request.Request;
import com.rallydev.rest.response.GetResponse;
import com.rallydev.rest.response.QueryResponse;
import com.rallydev.rest.util.Fetch;
import com.rallydev.rest.util.QueryFilter;

public class Connect {
	public static RallyRestApi restApi = null;
	
	public Connect(){
		try {
			restApi = new RallyRestApi(new URI(Constants.url),Constants.username,Constants.password);
		} catch (URISyntaxException e1) {
			// TODO Auto-generated catch block
			e1.getLocalizedMessage();
		}
 		restApi.setApplicationName("QueryExample");
	}
	
	public void closeConnection(){
		try {
			restApi.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.getLocalizedMessage();
		}
	}
	
	public QueryResponse getIterationDetails(){
		QueryRequest iterations = new QueryRequest("Iteration");
		iterations.setFetch(new Fetch("Name","StartDate","EndDate"));
	    //iterations.setQueryFilter(new QueryFilter("Iteration.StartDate", "<=", "today"));
	    //iterations.setQueryFilter(new QueryFilter("Iteration.EndDate", ">=", "today"));
		
		iterations.setWorkspace(Constants.workspacePath);
		iterations.setProject(Constants.projectPath);
		System.out.println("Workspace "+iterations.getWorkspace());
		System.out.println("Projects "+iterations.getProject());
		//Return up to 5, 1 per page
		iterations.setPageSize(1);
		iterations.setLimit(20);
		QueryResponse queryResponse = null;
		try {
			queryResponse = restApi.query(iterations);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return queryResponse;
		
	}

	
	public static boolean checkOwnerNull(JsonObject jsonObject){
		try{
			jsonObject.get("Owner");
			return true;
		}catch(Exception e){
			System.out.println("No Owner");
			}
		return false;
		
	}
	
	public static String buildDefectTable(QueryResponse queryResponse){
		String openDefectsContent="";
 		StringBuffer tableRow=null;
		openDefectsContent="<table border=\"1\" style=\"width:1700px;\" cellpadding=\"0\" cellspacing=\"0\">\r\n" + 
	     		"<tr>\r\n" +
	     		"<h1 style=\"margin:0;padding:0;\">Sprint Defect Summary</h1>\r\n" + 
	     		"</tr>\r\n" + 
	     		"<tr>\r\n" + 
	     		"<td style=\"background-color:#D3D3D3;width:100px;vertical-align:top;\">\r\n" + 
	     		"<b>Defect ID</b><br>\r\n" + 
	     		"</td>\r\n" + 
	     		"<td style=\"background-color:#D3D3D3;width:1000px;vertical-align:top;\">\r\n" + 
	     		"<b>Defect Summary</b>\r\n" + 
	     		"</td>\r\n" + 
	     		"<td style=\"background-color:#D3D3D3;width:200px;vertical-align:top;\">\r\n" + 
	     		"<b>Priority</b><br>\r\n" + 
	     		"</td>\r\n" + 
	     		"<td style=\"background-color:#D3D3D3;width:200px;vertical-align:top;\">\r\n" + 
	     		"<b>Owner</b><br>\r\n" + 
	     		"</td>\r\n" + 
	     		"<td style=\"background-color:#D3D3D3;width:200px;vertical-align:top;\">\r\n" + 
	     		"<b>State</b><br>\r\n" + 
	     		"</td>\r\n"; 
		try{
	             tableRow = new StringBuffer();
	             

		            if (queryResponse.wasSuccessful()) {
		                System.out.println(String.format("\nTotal results: %d", queryResponse.getTotalResultCount()));
		                for (JsonElement result : queryResponse.getResults()) {
		                    JsonObject defect = result.getAsJsonObject();
		                    JsonObject ownerJsonObject=new JsonObject();
		                    JsonObject ownerObj =new JsonObject();
		                    if(checkOwnerNull(defect)){
		                    	 	ownerObj.addProperty("EmailAddress"," ");
		                    		}else{
		                    	ownerJsonObject =defect.get("Owner").getAsJsonObject();	
		                        String ownerRef = ownerJsonObject.get("_ref").getAsString();
			                    GetRequest ownerRequest = new GetRequest(ownerRef);
			                    GetResponse ownerResponse;
								
									ownerResponse = restApi.get(ownerRequest);
								 
			                    ownerObj = ownerResponse.getObject();
		                    }
		                    
		              
		                    System.out.println(ownerObj);
		                    System.out.println(defect);
		                   tableRow.append("<tr><td style=\"background-color:#FFFFFF;width:100px;vertical-align:top;\">\r\n" + 
		           	     		"<b>"+defect.get("FormattedID").getAsString()+"</b><br>\r\n" + 
		        	     		"</td>\r\n" + 
		        	     		"<td style=\"background-color:#FFFFFF;width:1000px;vertical-align:top;\">\r\n" + 
		        	     		"<b>"+defect.get("Name").getAsString()+"</b>\r\n" + 
		        	     		"</td>\r\n" + 
		        	     		"<td style=\"background-color:#FFFFFF;width:200px;vertical-align:top;\">\r\n" + 
		        	     		"<b>"+defect.get("Priority").getAsString()+"</b><br>\r\n" + 
		        	     		"</td>\r\n" + 
		        	     		"<td style=\"background-color:#FFFFFF;width:200px;vertical-align:top;\">\r\n" + 
		        	     		"<b>"+ownerObj.get("EmailAddress").toString()+"</b><br>\r\n" + 
		        	     		"</td>\r\n" +
		        	     		"<td style=\"background-color:#FFFFFF;width:200px;vertical-align:top;\">\r\n" + 
		        	     		"<b>"+defect.get("State").getAsString()+"</b><br>\r\n" + 
		        	     		"</td>\r\n</tr>");
		                   System.out.println(String.format("\t%s - %s: Priority=%s, Owner=%s, State=%s",
		                            defect.get("FormattedID").getAsString(),
		                            defect.get("Name").getAsString(),
		                            defect.get("Priority").getAsString(),
		                            ownerObj.get("EmailAddress").toString(),
		                            defect.get("State").getAsString()));
		                }
		            tableRow.append("<tr><b>Total Defects=</b><b><i>"+ queryResponse.getTotalResultCount()+"</i></b></tr>");
		            } else {
		                System.err.println("The following errors occurred: ");
		                for (String err : queryResponse.getErrors()) {
		                    System.err.println("\t" + err);
		                }
		            }
		}catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
return openDefectsContent+tableRow+"</table>";
		        }
	
	
	public static String buildDefectTableByPriority(QueryResponse queryResponse){
		String openDefectsContent="";
 		StringBuffer tableRow=null;
 				
		openDefectsContent="<table border=\"1\" style=\"width:1700px;\" cellpadding=\"0\" cellspacing=\"0\">\r\n" + 
	     		"<tr>\r\n" +
	     		"<td><img src=\"http://www.sprint.com/global/images/logos/sprint_logo.gif\"/></td>"+
	     		"<td colspan=\"4\" style=\"background-color:#FFA500;width:1700px\">\r\n" + 
	     		"<h1 style=\"margin:0;padding:0;\">Sprint Defects By Status</h1>\r\n" + 
	     		"</td>\r\n" + 
	     		"</tr>\r\n" + 
	     		"<tr>\r\n" + 
	     		"<td style=\"background-color:#D3D3D3;width:100px;vertical-align:top;\">\r\n" + 
	     		"<b>Defect ID</b><br>\r\n" + 
	     		"</td>\r\n" + 
	     		"<td style=\"background-color:#D3D3D3;width:1000px;vertical-align:top;\">\r\n" + 
	     		"<b>Defect Summary</b>\r\n" + 
	     		"</td>\r\n" + 
	     		"<td style=\"background-color:#D3D3D3;width:200px;vertical-align:top;\">\r\n" + 
	     		"<b>Priority</b><br>\r\n" + 
	     		"</td>\r\n" + 
	     		"<td style=\"background-color:#D3D3D3;width:200px;vertical-align:top;\">\r\n" + 
	     		"<b>Owner</b><br>\r\n" + 
	     		"</td>\r\n" + 
	     		"<td style=\"background-color:#D3D3D3;width:200px;vertical-align:top;\">\r\n" + 
	     		"<b>State</b><br>\r\n" + 
	     		"</td>\r\n"; 
		try{
	             tableRow = new StringBuffer();
	             

		            if (queryResponse.wasSuccessful()) {
		                System.out.println(String.format("\nTotal results: %d", queryResponse.getTotalResultCount()));
		                for (JsonElement result : queryResponse.getResults()) {
		                    JsonObject defect = result.getAsJsonObject();
		                    JsonObject ownerJsonObject=new JsonObject();
		                    JsonObject ownerObj =new JsonObject();
		                    if(checkOwnerNull(defect)){
		                    	 	ownerObj.addProperty("EmailAddress"," ");
		                    		}else{
		                    	ownerJsonObject =defect.get("Owner").getAsJsonObject();	
		                        String ownerRef = ownerJsonObject.get("_ref").getAsString();
			                    GetRequest ownerRequest = new GetRequest(ownerRef);
			                    GetResponse ownerResponse;
								
									ownerResponse = restApi.get(ownerRequest);
								 
			                    ownerObj = ownerResponse.getObject();
		                    }
		                    
		              
		                    System.out.println(ownerObj);
		                    System.out.println(defect);
		                   tableRow.append("<tr><td style=\"background-color:#FFFFFF;width:100px;vertical-align:top;\">\r\n" + 
		           	     		"<b>"+defect.get("FormattedID").getAsString()+"</b><br>\r\n" + 
		        	     		"</td>\r\n" + 
		        	     		"<td style=\"background-color:#FFFFFF;width:1000px;vertical-align:top;\">\r\n" + 
		        	     		"<b>"+defect.get("Name").getAsString()+"</b>\r\n" + 
		        	     		"</td>\r\n" + 
		        	     		"<td style=\"background-color:#FFFFFF;width:200px;vertical-align:top;\">\r\n" + 
		        	     		"<b>"+defect.get("Priority").getAsString()+"</b><br>\r\n" + 
		        	     		"</td>\r\n" + 
		        	     		"<td style=\"background-color:#FFFFFF;width:200px;vertical-align:top;\">\r\n" + 
		        	     		"<b>"+ownerObj.get("EmailAddress").toString()+"</b><br>\r\n" + 
		        	     		"</td>\r\n" +
		        	     		"<td style=\"background-color:#FFFFFF;width:200px;vertical-align:top;\">\r\n" + 
		        	     		"<b>"+defect.get("State").getAsString()+"</b><br>\r\n" + 
		        	     		"</td>\r\n</tr>");
		                   System.out.println(String.format("\t%s - %s: Priority=%s, Owner=%s, State=%s",
		                            defect.get("FormattedID").getAsString(),
		                            defect.get("Name").getAsString(),
		                            defect.get("Priority").getAsString(),
		                            ownerObj.get("EmailAddress").toString(),
		                            defect.get("State").getAsString()));
		                }
		            tableRow.append("<tr><td><b>Total Defects=</b></td><td colspan=\\\"4\\\"><b>"+ queryResponse.getTotalResultCount()+"</b></td></tr>");
		            } else {
		                System.err.println("The following errors occurred: ");
		                for (String err : queryResponse.getErrors()) {
		                    System.err.println("\t" + err);
		                }
		            }
		}catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
return openDefectsContent+"</table>";
		        }
	
	
	public static String addIterationDetails(QueryResponse queryResponse){
		String iterationContent="";
		String iterationName="";
		Date iterationStartDate=new Date();
		Date iterationEndDate=new Date();
		String iterationStartDateString="";
		String iterationEndDateString="";
		System.out.println(queryResponse);
		System.out.println(String.format("\nTotal results: %d", queryResponse.getTotalResultCount()));
		 DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    	   //get current date time with Date()
    	   Date currentdate = new Date();
    	   
    	   System.out.println(dateFormat.format(currentdate));
		 if (queryResponse.wasSuccessful()) {
			 for (JsonElement result : queryResponse.getResults()) {
                 JsonObject iteration = result.getAsJsonObject();
                 try {
					iterationStartDate=dateFormat.parse(iteration.get("StartDate").getAsString());
					iterationEndDate=dateFormat.parse(iteration.get("EndDate").getAsString());
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                 if(iterationStartDate.before(currentdate) && iterationEndDate.after(currentdate)){
                	 System.out.println("My Wanted iteration "+iteration);
                	 iterationStartDateString=iterationStartDate.toString();
                	 iterationEndDateString=iterationEndDate.toString();
                	 iterationName=iteration.get("Name").toString();
                	 
                 }
                
                 
               //System.out.println("Iteration number "+iteration);                
                 }

		 }	 
		 iterationContent="<table border=\"1\" style=\"width:1000px;\" cellpadding=\"0\" cellspacing=\"0\">\r\n" + 
		 		"<tr>\r\n" + 
		 		"<h1 style=\"margin:0;padding:0;\">Iteration Details</h1>\r\n" + 
		 		"</tr>\r\n" + 
		 		"<tr>\r\n" + 
		 		"<b>Iteration Name: "+iterationName +"</b><br>\r\n" + 
		 		"</tr>\r\n" + 
		 		"<tr>\r\n" + 
		 		"<b>Iteration Start Date: "+iterationStartDateString+"</b><br>\r\n" + 
		 		"</tr>\r\n" + 
		 		"<tr>\r\n" + 
		 		"<b>Iteration End Date: "+iterationEndDateString+"</b><br>\r\n" + 
		 		"</tr>"; 
			 
		 
 		
 				
 		
 		return iterationContent+"</table>";
		        }
	
	public static String addStoryDetails(QueryResponse queryResponse) {
		// TODO Auto-generated method stub
		String storyContent="<table border=\"1\" style=\"width:1000px;\" cellpadding=\"0\" cellspacing=\"0\">\r\n" + 
				"<tr>\r\n" + 
				"<b><h1 style=\"margin:0;padding:0;\">User Stories Summary</h1></b>\r\n" + 
				"</tr>\r\n" + 
				"<tr><td style=\"background-color:#D3D3D3;margin:0;padding:0;\"><b>Story Name</b></td><td style=\"background-color:#D3D3D3;margin:0;padding:0;\"><b>Status</b></td>\r\n" + 
				"</tr>";
		 if (queryResponse.wasSuccessful()) {
			 for (JsonElement result : queryResponse.getResults()) {
                 JsonObject story = result.getAsJsonObject();
                 System.out.println("Story "+story);
                 storyContent=storyContent+"<tr><td>"+story.get("Name").toString().replace("\"", "")+"</td><td>"+story.get("ScheduleState").toString().replace("\"", "")+"</td>\r\n" + 
                 		"</tr>";
                               
                 }

		 }	 
		
		
		return storyContent+"</table>";
	}
	
	
		        
	}

