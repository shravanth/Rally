package com.rally;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.rallydev.rest.RallyRestApi;
import com.rallydev.rest.request.GetRequest;
import com.rallydev.rest.request.QueryRequest;
import com.rallydev.rest.response.GetResponse;
import com.rallydev.rest.response.QueryResponse;
import com.rallydev.rest.util.Fetch;
import com.rallydev.rest.util.QueryFilter;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.URI;
import java.net.URISyntaxException;

public class ConnectClass extends Connect{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	        
			OutputStream htmlfile = null;
	        PrintStream printhtml=null;
	 		RallyRestApi restApi = null;
	 		String initialContent="";
	 		String finalContent="";
	 		String openDefectsContent="";
	 		String iterationDetails="";
	 		String storyDetails="";
	 		try {
				restApi = new RallyRestApi(new URI(Constants.url),Constants.username,Constants.password);
			} catch (URISyntaxException e1) {
				// TODO Auto-generated catch block
				e1.getLocalizedMessage();
			}
	 		restApi.setApplicationName("QueryExample");
	 		
	 		        try {

	            System.out.println("Querying for defects...");

	            QueryRequest defects = new QueryRequest("defect");
	            defects.setFetch(new Fetch("FormattedID", "Name", "Priority","Owner", "State"));
	            defects.setQueryFilter(new QueryFilter("State", "<=", "Closed"));
	            defects.setQueryFilter(new QueryFilter("Iteration.StartDate", "<=", "today"));
	            defects.setQueryFilter(new QueryFilter("Iteration.EndDate", ">=", "today"));
	            defects.setWorkspace(Constants.workspacePath);
                defects.setProject(Constants.projectPath);
	            defects.setOrder("Priority ASC,FormattedID ASC");
	            System.out.println("Workspace "+defects.getWorkspace());
	            System.out.println("Projects "+defects.getProject());
	            //Return up to 5, 1 per page
	            defects.setPageSize(1);
	            defects.setLimit(20);
	            QueryResponse queryResponse = restApi.query(defects);
	           
				try {
					htmlfile = new FileOutputStream(new File(System.getProperty("user.dir")+"//test.html"));
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.getLocalizedMessage();
				}
	        printhtml = new PrintStream(htmlfile);
	        initialContent="<html><head><title>Sprint Status Report</title></head><body>\r\n" + 
	        		"<table border=\"1\" style=\"width:1000px;\" cellpadding=\"0\" cellspacing=\"0\">\r\n" + 
	        		"<tr>\r\n" + 
	        		"<td><img src=\"http://www.sprint.com/global/images/logos/sprint_logo.gif\"/></td>\r\n" + 
	        		"<td colspan=\"4\" style=\"background-color:#FFA500;width:1700px\">\r\n" + 
	        		"<h1 style=\"margin:0;padding:0;\">Sprint Status Report</h1>\r\n" + 
	        		"</td>\r\n" + 
	        		"</tr>\r\n" + 
	        		"</table>";
	        finalContent="</body></html>";
	        openDefectsContent=buildDefectTable(queryResponse);	
	        
	        
	        QueryRequest iterations = new QueryRequest("Iteration");
			iterations.setFetch(new Fetch("Name","StartDate","EndDate"));
		   	iterations.setWorkspace(Constants.workspacePath);
			iterations.setProject(Constants.projectPath);
			System.out.println("Workspace "+iterations.getWorkspace());
			System.out.println("Projects "+iterations.getProject());
			//Return up to 5, 1 per page
			iterations.setPageSize(1);
			iterations.setLimit(20);
			QueryResponse iterationQueryResponse = null;
			try {
				iterationQueryResponse = restApi.query(iterations);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			iterationDetails=addIterationDetails(iterationQueryResponse);
			
			
			 QueryRequest stories = new QueryRequest("HierarchicalRequirement");
			 stories.setFetch(new Fetch("Name", "FormattedID","ScheduleState"));
			 stories.setQueryFilter(new QueryFilter("Iteration.StartDate", "<=", "today"));
			 stories.setQueryFilter(new QueryFilter("Iteration.EndDate", ">=", "today"));
			 stories.setWorkspace(Constants.workspacePath);
			 stories.setProject(Constants.projectPath);
				System.out.println("Workspace "+stories.getWorkspace());
				System.out.println("Projects "+stories.getProject());
				//Return up to 5, 1 per page
				stories.setPageSize(1);
				stories.setLimit(20);
				QueryResponse storyQueryResponse = null;
				try {
					storyQueryResponse = restApi.query(stories);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				storyDetails=addStoryDetails(storyQueryResponse);
	        
	        
	        printhtml.print(initialContent);
	        printhtml.print(iterationDetails);
	        printhtml.print(storyDetails);
        	printhtml.print(openDefectsContent);
        	printhtml.print(finalContent);
     		 printhtml.close();    
		            //Release resources
		        	
		     		 try {
						htmlfile.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.getLocalizedMessage();
					}
		            try {
						restApi.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.getLocalizedMessage();
					
		        }
		    }catch(Exception e){
		    	System.out.println("Error "+e.getLocalizedMessage());
		    }
	 		        }

}

